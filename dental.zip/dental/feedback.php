<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php include('dbcon.php'); ?>
<?php include('navbar_dasboard.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">
				<div class="span3">
					<p><strong>Today is:</strong></p>
				 <div class="alert alert-success">
                        <i class="icon-calendar icon-large"></i>
                        <?php
                     	  $Today = date('l, F d, Y');
                          echo $Today;
                        ?>
                       
                    </div>		
				<div class="alert alert-info">Time Guide for Each Number</div>
						<p>Number 1  - 09:00 am - 10:00 am</p>
						<p>Number 2  - 10:00 am - 11:00 am</p>
						<p>Number 3  - 11:00 am - 12:00 am</p>
						<p>Number 4  - 01:00 pm - 02:00 pm</p>
						<p>Number 5  - 02:00 pm - 03:00 pm</p>
						<p>Number 6  - 03:00 pm - 04:00 pm</p>
						<p>Number 7  - 04:00 pm - 05:00 pm</p>		
				<br/>						
							
				<div class="alert alert-info">Office Hours</div>
					<p>Dr.Mansoor ahamed</p>
					<p>Timings: 09:00 am to 05:00 pm </p>
					<p>Address:Dental Care Clinic near jigani link road Bangalore 560099</p>
				<br/>					
					
				<div class="alert alert-info">Testimonial</div>
				<p>
					I was delighted with the treatment.
					The treatment was explained precisely to me and the price was quoted right at the beginning which is exactly what the price was at the end.
					 I am extremely happy with the quality of the treatment.
					</p>
				</div>



<div class="span6">
<br>
<div class="alert alert-info">Please send valuable feedback</div>
<?php
	$query=mysql_query("select * from members where member_id='$session_id'")or die(mysql_error());
	$row=mysql_fetch_array($query);
	$id=$row['firstname'];			
?>
<table class="table  table-bordered">
   <thead>
    <tr>
        <th>Feedback list</th>  
	<th> date of feedback</th>                     
   </tr>
  </thead>
      <tbody>
      <?php $user_query=mysql_query("select * from feedback where username='$id'")or die(mysql_error());
	while($row=mysql_fetch_array($user_query)){
	 ?>
	 <tr class="del<?php echo $id ?>">
         <td><?php echo $row['message']; ?></td>
	 <td><?php echo $row['date']; ?></td>
	 <?php } ?>
       </tbody>
</table>
<p><a  href="#adduser" data-toggle="modal" class="btn btn-info" ><i class="icon-plus"></i>&nbsp;Give Feedback</a></p>
	<div id="adduser" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-body">
				<div class="alert alert-info"><strong>Type message below</strong></div>
					<form class="form-horizontal" method="post">
					<div class="control-group">
						<label class="control-label" for="inputPassword">Feedback</label>
							<div class="controls">
								<textarea name="message" rows="3"></textarea>
							</div>
					</div>
					<div class="control-group">
						<div class="controls">
						<button name="submit" type="submit" class="btn btn-success"><i class="icon-save icon-large"></i>&nbsp;Send</button>
						</div>
					</div>
   					 </form>
		</div>		
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i>&nbsp;Close</button>
</div>
</div>
</div>
<?php
    $Today = date('l, F d, Y');
    if (isset($_POST['submit'])){
	$message=$_POST['message'];
	mysql_query("insert into feedback (username,message,date) values ('$id','$message','$Today')")or die(mysql_error());
}
?>

			<div class="span3">
				<!-- <img src="img/32x32/facebook.png">
				<img src="img/32x32/twitter.png">
				<img src="img/32x32/rss.png"> -->
				    <ul class="nav nav-list">
					 <div class="alert alert-danger"><li class="nav-header">NOTE</li></div>
						
					
				<?php 
				$note_query = mysql_query("select * from note ")or die(mysql_error());
				$note_count =mysql_num_rows($note_query);
				while($note_row = mysql_fetch_array($note_query)){
				if ($note_count > 0){ ?>
				
				<li><i class="icon-stop icon-large"></i>&nbsp;<?php echo $note_row['message'] ?></li>
				<?php
				}  } 
				?>
				</ul>
				<br>
			
				
				<div class="alert alert-info">List of Services</div>
						<table class="table  table-bordered">
                            
                                <thead>
                                    <tr>
                                        <th>Service Offer</th>
                                        <th>Price</th>                                 
                                     
                                    </tr>
                                </thead>
                                <tbody>
								 
                                  <?php $user_query=mysql_query("select * from service")or die(mysql_error());
									while($row=mysql_fetch_array($user_query)){
									$id=$row['service_id']; ?>
									 <tr class="del<?php echo $id ?>">
                                    <td><?php echo $row['service_offer']; ?></td> 
                                    <td><?php echo $row['price']; ?></td>                         
									<?php } ?>
                           
                                </tbody>
                            </table>
				<div class="alert alert-info">Dr.Mansoor ahamed</div>	
					<img  class="img img-polaroid" src="images/c.jpg">
				</div>
				
			</div>
		</div>
    </div>
<?php include('footer.php') ?>