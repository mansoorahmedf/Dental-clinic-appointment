<div id="edit<?php echo $id; ?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-body">
	<div class="alert alert-info"><strong>Edit Appointment</strong></div>
	

<form class="form-horizontal" method="POST">
    <div class="control-group">
    <label class="control-label" for="inputEmail">Date</label>
    <div class="controls">
    <input type="text" value="<?php  echo $row['date'];?>" class="w8em format-d-m-y highlight-days-67 range-low-today" name="date" id="sd" maxlength="10" style="border: 3px double #CCCCCC;" required/>
    </div>
    </div>
    <div class="control-group">
    <label class="control-label" for="inputPassword">Service</label>
    <div class="controls">
							
		<select name="service" required>
			<option> <?php  echo $service_row['service_offer'];?> </option>
		<?php $query=mysql_query("select * from service")or die(mysql_error());
		while($row=mysql_fetch_array($query)){
		?>
	
		<option value="<?php echo $row['service_id']; ?>"><?php echo $row['service_offer'] ?></option>
		<?php } ?>
		</select>		

    </div>
    </div>
    <div class="control-group">
    <div class="controls">
    <button type="submit" name="sub" class="btn btn-success"><i class="icon-check icon-large"></i>&nbsp;Update</button>
    </div>
    </div>
    </form>



<div class="modal-footer">
<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i>&nbsp;Close</button>
</div>
</div>
</div>

<?php
if (isset($_POST['sub'])){
$date = $_POST['date'];
$service = $_POST['service'];
$query = mysql_query("select * from schedule where date = '$date' and member_id = '$session_id' ")or die(mysql_error());
$count = mysql_num_rows($query);
if ($count > 0){ ?>
<script>
alert('You have already schedule on this date');
</script>
	<?php
	}else{
	$equal = $count + 1 ;
	?>
	
<?php 
$query = mysql_query("select * from schedule where date = '$date'");
$num = mysql_num_rows($query);
if($num >6){ ?>
		<script>
		alert('Sorry No more Appointment available for this date. check for other dates.....!');
		</script>
<?php
	}else{	?>
		<div class="question"> 
		<div class="alert alert-success">Your the number <strong><?php echo $num+1; ?></strong> client in this date <strong><?php echo  $date; ?></strong></div>
		<form method="POST" action="edit_yes.php">
		<input type="hidden" name="session_id" value="<?php echo $session_id; ?>" >
		<input type="hidden" name="date1" value="<?php echo $date; ?>" >
		<input type="hidden" name="service1" value="<?php echo $service; ?>" >
		<input type="hidden" name="equal" value="<?php echo $num+1; ?>" >
		<p>Are you sure you want to set your Appointment on this date?</p>
		<button name="yes" class="btn btn-success"><i class="icon-check icon-large"></i>&nbsp;Yes</button> &nbsp;  <a href="dasboard.php" class="btn"><i class="icon-remove"></i>&nbsp;No</a>
		</form>
		</div>
		<br>
		<br>
		<?php }}}   ?>
	<!-- end reservation -->