﻿<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php include('dbcon.php'); ?>
<?php include('navbar_dasboard.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">
				
				<div class="span3">
					 <!--   <ul class="nav nav-tabs nav-stacked">
							<li class="active">
							<a href="#"><i class="icon-pencil icon-large"></i>&nbsp;Create Account</a>
							</li>
					
						</ul> -->
						<p><strong>Today is:</strong></p>
				 <div class="alert alert-success">
                        <i class="icon-calendar icon-large"></i>
                        <?php
                     	  $Today = date('l, F d, Y');
                          echo $Today;
                        ?>
                    </div>	
		<div class="alert alert-info">Time Guide for Each Number</div>
						<p>Number 1  - 09:00 am - 10:00 am</p>
						<p>Number 2  - 10:00 am - 11:00 am</p>
						<p>Number 3  - 11:00 am - 12:00 am</p>
						<p>Number 4  - 01:00 pm - 02:00 pm</p>
						<p>Number 5  - 02:00 pm - 03:00 pm</p>
						<p>Number 6  - 03:00 pm - 04:00 pm</p>
						<p>Number 7  - 04:00 pm - 05:00 pm</p>	
				
						
					
				<div class="alert alert-info">Office Hours</div>
						<p>Dr.Manesh Dhami</p>
					<p>Timings: 09:00 am to 05:00 pm </p>
					<p>Address:Dental Care Clinic near jigani link road Bangalore 560099</p>
				
					
					
					
				<div class="alert alert-info">Testimonial</div>
				<div class="testimonial_div">
					<p>
					I was delighted with the treatment.
					The treatment was explained precisely to me and the price was quoted right at the beginning which is exactly what the price was at the end.
					 I am extremely happy with the quality of the treatment.
					</p>
					</div>		
				</div>
				<div class="span6">
				<br>	
				<div class="alert alert-info">Edit Personal Information</div>				
				<div class="yes"><h3>your account updated successfully....!</h3></div>
<br>
				</div>

				<div class="span3">
				<!-- <img src="img/32x32/facebook.png">
				<img src="img/32x32/twitter.png">
				<img src="img/32x32/rss.png"> -->
				    <ul class="nav nav-list"> 
					 <div class="alert alert-danger"><li class="nav-header">NOTE</li></div>
						
					
				<?php 
				$note_query = mysql_query("select * from note ")or die(mysql_error());
				$note_count =mysql_num_rows($note_query);
				while($note_row = mysql_fetch_array($note_query)){
				if ($note_count > 0){ ?>
				
				<li><i class="icon-stop icon-large"></i>&nbsp;<?php echo $note_row['message'] ?></li>
				<?php
				}  } 
				?>
				</ul>
				<br>
			
				
				<div class="alert alert-info">List of Services</div>
						<table class="table  table-bordered">
                            
                                <thead>
                                    <tr>
                                        <th>Service Offer</th>
                                        <th>Price</th>                                 
                                     
                                    </tr>
                                </thead>
                                <tbody>
								 
                                  <?php $user_query=mysql_query("select * from service")or die(mysql_error());
									while($row=mysql_fetch_array($user_query)){
									$id=$row['service_id']; ?>
									 <tr class="del<?php echo $id ?>">
                                    <td><?php echo $row['service_offer']; ?></td> 
                                    <td><?php echo $row['price']; ?></td>                         
									<?php } ?>
                           
                                </tbody>
                            </table>
				<div class="alert alert-info">Dr. Manesh dhami</div>	
					<img  class="img img-polaroid" src="images/c.jpg">
				</div>
				
			</div>
		</div>
    </div>
<?php include('footer.php') ?>