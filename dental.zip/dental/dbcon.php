<?php
mysql_select_db('database',mysql_connect('localhost','root',''))or die(mysql_error());
?>
