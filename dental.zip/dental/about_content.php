<div class="alert alert-info"><strong>About US</strong></div>
<div class="about">
<p>
Dentists are doctors who specialize in oral health.
Dentists can specialize in a number of  fields such as restoration,braces,gums,dentures,radiology,surgery etc.
</p>
<p>
<table><tr><th>Their responsibility include:</th></tr>
<tr><td>Diagnosing oral diseases.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>Ensuring the safe adminstration of anesthetics.</td></tr>
<tr><td>Promoting oral health and disease prevention.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>Monitoring growth and development of the teeth and jaws.</td></tr>
<tr><td>Interpreting x-rays and diagnostic tests.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>Creating treatment plans to maintain or restore the oral health of their patients.</td></tr>
<tr><td>Managing oral trauma and other emergency situations.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>Performing surgical procedures on the teeth,bone and soft tissues of the oral cavity.</td></tr>
</table>
</p>
</div>
<div class="contact_us">
		<div class="caption_index_2">VISIT OUR OFFICE</div>	
		<p>Office Hours</p>
		<p>Timings: 09:00 am to 05:00 pm </p>
		<p>Address:Dental Care Clinic near new horizon  college  Bangalore 560103</p>
<br/>
<br/>
		</div>
        
