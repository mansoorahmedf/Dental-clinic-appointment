<?php include('header.php'); ?>
<?php include('session.php'); ?>
    <div class="container">

	<div class="row">	
						<div class="span3">
						<?php include('sidebar.php'); ?>
						</div>
						<div class="span9">
							<img src="../img/dr.png" class="img-rounded">
								<?php include('navbar_dasboard.php') ?>
						    <div class="alert alert-info">
                                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                                    <strong><i class="icon-user icon-large"></i>&nbsp;Feedback list Table</strong>
                            </div>
								
                            <table cellpadding="0" cellspacing="0" border="0" class="table  table-bordered" id="example">
                            
                                <thead>
                                    <tr>
					 <th>Username</th>   
                                        <th>Message</th>  
					 <th>Sent on</th>                               
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
								 
                                  <?php $user_query=mysql_query("select * from feedback")or die(mysql_error());
					while($row=mysql_fetch_array($user_query)){
					$id=$row['feedback_id']; ?>
					<tr class="del<?php echo $id ?>">
                                        <td><?php echo $row['username']; ?></td> 
					 <td><?php echo $row['message']; ?></td> 
					 <td><?php echo $row['date']; ?></td> 
                                    <td width="60">
                                        <a href="#delete<?php echo $id ?>" data-toggle="modal"  rel="tooltip"  title="Delete" id="<?php echo $id; ?>" class="btn btn-danger"><i class="icon-trash icon-large"></i></a>
						<?php include('delete_feedback_modal.php'); ?>
									   
						</td>
						</tr>
						<?php } ?>
                           
                                </tbody>
                            </table>
							


	</div>
    </div>
<?php include('footer.php') ?>