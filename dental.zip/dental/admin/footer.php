<div class="container">   
   <footer class="footer">
      <div class="container">
	  <div class="foot-margin">
       <p> <a>Developed by: mansoor ahamed & manjunath m n</a></p>
      </div>
      </div>
    </footer>
</div>
</body>
</html>