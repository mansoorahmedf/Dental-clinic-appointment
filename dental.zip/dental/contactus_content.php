
<div class="alert alert-info"><strong>Contact US</strong></div>
<div class="about">
<p>Dental Software is designed and built to meet all the requirements of a dental clinic and to help the dentist in managing their clinics in an effective manner. With just a few clicks the user can schedule faster.
Using this it is possible to keep a track of a database for clinic like information about the patient like appointment schedule, personal records images. The dental software is used for collecting, managing, saving, and retrieving medical information for the patients. Patient records are used by the dentists in order to organize the records of the patients in their practice.
</p>
<br/>
<br/>
<table><tr><td><img  class="img img-polaroid" src="images/c.jpg"></td><td>&nbsp;</td><td>
<table><tr><td>Dr. Mansoor ahamed </td></tr>
<tr><td>Qualification : MBBS</td></tr>
<tr><td>Experience : 10 Years</td></tr>

<tr><td></td></tr>
<tr><td>Mobile no:8105803856</td></tr>
<tr><td>E-mail : mansoorahamedfa@gmail.com</td></tr>
<tr><td>Address:Dental Care Clinic, near new horizon college Bangalore-560099.</td></tr></table>
</td></tr></table>
<br/>
<br/>
</div>
