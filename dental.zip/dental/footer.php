    <footer class="footer">
      <div class="container">
	  <div class="foot-margin">
          <p> <a>Developed by: Mansoor ahamed& manjunath m n</a></p>
      </div>

      </div>
    </footer>
	
		<script type="text/javascript">
			$(function() {
				$('#da-thumbs > li').hoverdir();
			});
		</script>
<?php include('tooltip.php'); ?>

</body>
</html>