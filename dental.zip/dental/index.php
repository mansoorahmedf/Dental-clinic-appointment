<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
<?php include('dbcon.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">
				<div class="span12">
				 <img src="img/dr.png">
		<div class="login_sign_up">
	<a rel="tooltip"  data-placement="left" title="Click Here to signup" id="signup" href="signup.php"  class="btn btn-info btn-large"><i class="icon-signin icon-large"></i>&nbsp;Register</a>
	<p><a rel="tooltip"  data-placement="bottom" title="Click Here to Sign up" id="signup" href="signup.php">Not a Member? Sign Up Now</a></p>
				</div>
				<!--- login -->
				<?php include('login_modal.php'); ?>
				<!-- end login -->
				</div>
		</div>
    </div>
<br/>
<br/>
<?php include('footer.php') ?>