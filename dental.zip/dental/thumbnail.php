	<ul id="da-thumbs" class="da-thumbs">
					
					<li>
						<a href="images/n.jpg">
						<img src="images/n.jpg"  height="100" width="160"/>
						<div><span>Image 1</span></div>
						</a>
					</li>
					<li>
						<a href="images/m.jpg">
						<img src="images/m.jpg"  height="100" width="160" />
						<div><span>Image 2</span></div>
						</a>
					</li>
					<li>
						<a href="images/p.jpg">
						<img src="images/p.jpg"  height="100"  width="160"/>
						<div><span>Image 3</span></div>
						</a>
					</li>
					<li>
						<a href="images/b.jpg">
						<img src="images/b.jpg"  height="100" width="160"/>
						<div><span>Image 4</span></div>
						</a>
					</li>
					<li>	<a href="images/z.jpg">
						<img src="images/z.jpg"  height="100" width="160"/>
						<div><span>Image 5</span></div>
						</a>
					</li>
					<li>
						<a href="images/d.jpg">
						<img src="images/d.jpg" height="100" width="150"/>
						<div><span>Image 6</span></div>
						</a>
					</li>
								
	</ul>
						<!--	<div class="social_con">
								<div class="social_index">
								<div class="mm"><img src="img/32x32/facebook.png"></div><div class="fb">Like us On facebook</div>						
								</div>
							<div class="social_index">
							<div class="mm"><img src="img/32x32/twitter.png"></div><div class="twitter">Follow us on twitter</div>
							</div>
							<div class="social_index">
							<div class="mm"><img src="img/32x32/rss.png"></div><div class="rss">Feed us On Rss</div>
							</div> -->
							</div>
                       
                       