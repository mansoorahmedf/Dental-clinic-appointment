-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2015 at 10:24 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `database`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
`feedback_id` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `date` varchar(100) CHARACTER SET swe7 NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `username`, `message`, `date`) VALUES
(34, 'manesh', 'hello sir', 'Sunday, November 15, 2015'),
(37, 'manesh', 'kljohou', 'Sunday, November 15, 2015'),
(38, 'lokesh', 'good one\r\n', 'Sunday, November 15, 2015'),
(42, 'lokesh', 'awesome experience', 'Monday, November 16, 2015'),
(43, 'jaggi', 'waiting for my turn', 'Monday, November 16, 2015'),
(44, 'guru', 'previously had pain ', 'Monday, November 16, 2015'),
(45, 'durga', 'what will be the total cost for trauma including service charge', 'Monday, November 16, 2015'),
(46, 'anbu', 'expecting i will not feel pain', 'Monday, November 16, 2015'),
(47, 'manesh', 'EVERYTHING WAS PERFECT\r\n', 'Monday, November 16, 2015'),
(48, 'manesh', 'thank you doctor', 'Thursday, January 01, 1970');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
`member_id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact_no` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`member_id`, `firstname`, `lastname`, `middlename`, `address`, `email`, `contact_no`, `age`, `gender`, `username`, `password`) VALUES
(1, 'manesh', 'dhami', 'aryan', 'bommasandra', 'maneshdhami@yahoo.com', '0946651154', 24, 'Male', 'mn', 'mn'),
(10, 'lokesh', 'kumar', 's', 'bangalore', 'loki@gmail.com', '9900909898', 24, 'Male', 'loki', 'loki'),
(11, 'durga', 'prasad', 'koja', 'bommanahalli', 'durgaprasad@gmail.com', '9987654357', 25, 'Male', 'durga', 'DD'),
(12, 'anbu', 'kumar', 'rowdi', 'tamil nadu', 'anbu@gmail.com', '8976545654', 27, 'Male', 'anbu', 'aa'),
(13, 'jaggi', 'pandey', 'singh', 'kr market', 'jagga@gmail.com', '9898763122', 44, 'Male', 'jagga', 'jj'),
(14, 'guru', 'raja', '', 'hosa road', 'guru@gmail.com', '8645654345', 25, 'Male', 'guru', 'gg'),
(15, 'manesh', 'dhami', 'd', 'bommasandra', 'maneshdhami@gmail.com', '9880564863', 26, 'Male', 'manesh', 'manesh'),
(16, 'priya', 'b', 'kumari', 'anekal', 'priya@gmail.com', '9880564876', 34, 'Female', 'priya', '1234'),
(17, 'samith', 'bist', 'b', 'tirupalya', 'samith@yahoo.com', '9989775454', 54, 'Male', 'samith', 'samith'),
(18, 'rachit', 'khadka', 'bahadur', 'nepal', 'rachit@hotmail.com', '9875421231', 5, 'Male', 'rachit', 'rachit'),
(19, 'kiran56', '676', '676', 'hbhgbv76785hvhhvb3#$%^', 'mnnnnnnn', '98937y7ey7', 34, 'Male', 'gggyy769767tg', '66tt');

-- --------------------------------------------------------

--
-- Table structure for table `note`
--

CREATE TABLE IF NOT EXISTS `note` (
`note_id` int(11) NOT NULL,
  `message` varchar(200) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `note`
--

INSERT INTO `note` (`note_id`, `message`) VALUES
(7, 'carry all past documents during appointment time.'),
(9, 'be in time during your date of appointment .');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
`id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `date` varchar(100) NOT NULL,
  `service_id` int(11) NOT NULL,
  `Number` int(11) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=226 ;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`id`, `member_id`, `date`, `service_id`, `Number`, `status`) VALUES
(94, 10, '26/11/2015', 8, 1, 'Pending'),
(101, 1, '25/11/2015', 7, 1, 'Done'),
(103, 1, '24/11/2015', 7, 1, 'Done'),
(106, 10, '23/11/2015', 7, 1, 'Done'),
(118, 10, '04/12/2015', 7, 2, 'Pending'),
(119, 11, '04/12/2015', 8, 3, 'Pending'),
(122, 11, '01/12/2015', 7, 3, 'Pending'),
(125, 14, '04/12/2015', 8, 6, 'Pending'),
(129, 1, '26/11/2015', 8, 2, 'Pending'),
(130, 13, '08/12/2015', 7, 1, 'Pending'),
(132, 10, '18/11/2015', 7, 1, 'Done'),
(135, 12, '23/11/2015', 7, 2, 'Done'),
(136, 15, '15/12/2015', 12, 1, 'Pending'),
(139, 15, '10/12/2015', 10, 1, 'Pending'),
(140, 13, '16/11/2015', 8, 1, 'Done'),
(141, 14, '16/11/2015', 10, 2, 'Done'),
(143, 12, '16/11/2015', 11, 4, 'Done'),
(144, 15, '25/11/2015', 11, 3, 'Done'),
(146, 15, '30/11/2015', 12, 1, 'Pending'),
(147, 12, '27/11/2015', 7, 2, 'Pending'),
(149, 12, '08/12/2015', 12, 2, 'Pending'),
(152, 14, '01/12/2015', 7, 2, 'Pending'),
(153, 14, '02/12/2015', 12, 1, 'Pending'),
(154, 10, '01/12/2015', 10, 3, 'Pending'),
(156, 10, '27/11/2015', 10, 4, 'Pending'),
(157, 10, '30/11/2015', 7, 2, 'Pending'),
(158, 13, '27/11/2015', 12, 5, 'Pending'),
(159, 13, '25/11/2015', 11, 5, 'Done'),
(162, 11, '30/11/2015', 12, 3, 'Pending'),
(163, 11, '27/11/2015', 11, 6, 'Pending'),
(164, 11, '10/12/2015', 8, 2, 'Pending'),
(165, 11, '25/12/2015', 10, 1, 'Pending'),
(166, 1, '30/11/2015', 11, 4, 'Pending'),
(167, 1, '09/12/2015', 12, 2, 'Pending'),
(170, 13, '14/12/2015', 8, 1, 'Pending'),
(171, 10, '16/12/2015', 11, 1, 'Pending'),
(172, 16, '30/11/2015', 8, 5, 'Pending'),
(173, 16, '01/12/2015', 12, 5, 'Pending'),
(174, 16, '10/12/2015', 20, 3, 'Pending'),
(175, 17, '16/12/2015', 20, 2, 'Pending'),
(176, 17, '04/12/2015', 12, 5, 'Pending'),
(177, 17, '01/12/2015', 20, 6, 'Pending'),
(178, 17, '17/12/2015', 26, 1, 'Pending'),
(179, 1, '14/12/2015', 26, 2, 'Pending'),
(180, 18, '27/11/2015', 20, 5, 'Pending'),
(181, 18, '02/12/2015', 34, 2, 'Pending'),
(182, 1, '01/01/2016', 11, 1, 'Pending'),
(183, 1, '13/01/2016', 20, 1, 'Pending'),
(184, 1, '25/12/2015', 20, 2, 'Pending'),
(194, 17, '10/12/2015', 8, 4, 'Pending'),
(195, 17, '26/11/2015', 11, 3, 'Pending'),
(196, 17, '27/11/2015', 10, 6, 'Pending'),
(207, 17, '22/12/2015', 34, 1, 'Pending'),
(208, 17, '18/12/2015', 10, 1, 'Pending'),
(209, 17, '30/12/2015', 11, 1, 'Pending'),
(211, 14, '29/12/2015', 10, 1, 'Pending'),
(212, 15, '30/12/2015', 11, 3, 'Pending'),
(216, 15, '15/01/2016', 12, 1, 'Pending'),
(217, 15, '15/01/2016', 12, 1, 'Pending'),
(218, 11, '02/12/2015', 11, 3, 'Pending'),
(219, 11, '14/12/2015', 20, 3, 'Pending'),
(220, 18, '08/12/2015', 10, 3, 'Pending'),
(221, 18, '30/12/2015', 12, 7, 'Pending'),
(222, 18, '21/12/2015', 7, 1, 'Pending'),
(223, 13, '31/12/2015', 20, 1, 'Pending'),
(224, 1, '31/12/2015', 12, 2, 'Pending'),
(225, 1, '20/01/2016', 20, 1, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE IF NOT EXISTS `service` (
`service_id` int(11) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `service_offer` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`service_id`, `price`, `service_offer`) VALUES
(7, '200.00', 'root canal'),
(8, '500.00', 'trauma'),
(10, '500.00', 'surgery'),
(11, '5000.00', 'clipping'),
(12, '1000.00', 'crown fitting'),
(20, '300.00', 'check up'),
(26, '3000.00', 'tooth x-ray'),
(34, '300.00', 'cleaning tooth');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`) VALUES
(6, 'admin', 'admin'),
(10, 'lokesh', 'lokesh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
 ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
 ADD PRIMARY KEY (`member_id`), ADD UNIQUE KEY `email` (`email`), ADD UNIQUE KEY `contact_no` (`contact_no`), ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `note`
--
ALTER TABLE `note`
 ADD PRIMARY KEY (`note_id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
 ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`user_id`), ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
MODIFY `feedback_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `note`
--
ALTER TABLE `note`
MODIFY `note_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=226;
--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
