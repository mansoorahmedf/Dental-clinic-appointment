﻿	<div class="testimonial">	
		<div class="caption_index_2">TESTIMONIAL</div>
			<div class="testimonial_div">
			<p>
			I was delighted with the treatment. Despite me being a somewhat difficult patient Dr. Terry Lee was really gentle, patient and understanding.
            The treatment was explained precisely to me and the price was quoted right at the beginning which is exactly what the price was at the end.
            The transformation to my teeth and to my life in general has been amazing.I know have a smile that I am not afraid to show anymore. I am extremely happy with the quality of the treatment.
			</p>
			</div>
		<div class="testimonial_div1">
			</div></div>
		<div class="contact_us">
		<div class="caption_index_2">VISIT OUR OFFICE</div>	
		<p>Office Hours</p>
		<p>Monday - Firday (09:00 am to 05:00 pm)</p>
		<p>Address:Wisdom dental care near  new horizon college Bangalore 56013</p>
		</div>
        
        
					